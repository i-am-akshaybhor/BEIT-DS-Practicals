Steps to run this program
(Make sure you are in the folder containing the java files)

Step 1 - On Terminal 1
javac *.java

Step 2 - On Terminal 2
java Server

Step 3 - On Terminal 3
java Client